# WIS Application Website

A responsive, single-page WIS / State 625 application form with a dark military-premium design.

## Files
- `index.html` — the complete website.

## Before publishing: connect form submissions

GitHub Pages hosts the page but does not receive/store form submissions. This starter uses Formspree.

1. Create an account at https://formspree.io/
2. Create a new form and set the notification email for the WIS leadership member who should receive applications.
3. Copy the Form Endpoint / form ID. It looks like `https://formspree.io/f/xxxxxxxx`.
4. Open `index.html` in a text editor.
5. Find `YOUR_FORMSPREE_ID` in the `<form ... action="...">` line and replace it with your actual ID. Example:
   `action="https://formspree.io/f/abcdwxyz"`
6. Save the file.

File uploads and plan limits depend on the form service plan. Test with a sample application before sharing the link.

## Publish with GitHub Pages

1. Sign in at https://github.com/
2. Click **New repository**.
3. Name it `wis-application` (or another name you like).
4. Set it to **Public**, then create the repository.
5. Choose **Add file → Upload files**.
6. Upload `index.html` (not the ZIP file).
7. Click **Commit changes**.
8. Open the repository's **Settings → Pages**.
9. Under **Build and deployment**, choose **Deploy from a branch**.
10. Choose branch `main` and folder `/(root)`, then click **Save**.
11. Wait a minute or two. Your website should appear at:
    `https://YOUR-GITHUB-USERNAME.github.io/wis-application/`

## Test checklist
- Open the published link on a phone.
- Submit a test application using an email you can check.
- Confirm the submission arrives in the configured inbox.
- Test an image upload if you plan to accept screenshots.
- Only then share the public application link.

## Editing
Edit `index.html` in GitHub using the pencil icon, then commit changes. GitHub Pages republishes the page automatically.
